<?php

require_once('docs/common.php');

// 99% height and width is a hack fix for overflowing containers

echo 
<body class="bg-dark">
    <div class="row" style="width: 99%; height:99%">
        Common/build_navigation()
        .<main class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
            Common/build_topbar()
            .<div class="pt-5 d-flex justify-content-center contentcrop content">
                <div>
                    <h1> "Welcome to NoPHP" </h1>
                    .<p class="lead"> "by Artur Zaytsev with help (and hate) from Kunal Dandekar" </p>
                    .<p> nl2br(`
                    This book assumes that you are using NoPHP version 0.1.5 or later. 
                    Some topics covered may become outdated by the next major release.
                    
                    You can use the side bar to navigate to different viewcontrollers and topics.
                    `)
                    </p>
                </div>
            </div>
        </main>
    </div>
</body>;



?>
## Running the application
```bash
$ docker-compose up --build
```
<?php
namespace UsersRepo;
require_once("app/repositories/repo.php");

class Users extends Repository {
    function getAll()
    {
            $sql = "SELECT * FROM user";
            $users = sql_query($this->conn, $sql);

            return $users;
    }

    function getByID($id) {
            $sql = "SELECT * FROM user WHERE id=?";
            $users = sql_query_sane($this->conn, $sql, [$id]);

            return $users[0];
    }
}

?>
<?php
session_destroy();
echo redirect('/');
?>
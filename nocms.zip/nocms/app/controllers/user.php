<?php

class UserController {
    public function __construct() 
    {
        require_once("app/models/user.php");
        $this->conn = sql_connect("db.sql");
        require_once("app/repositories/users.php");
        $this->repo = new Users();
    }

    public function login($email)
    {
        // Check if user exists
        $sql = "SELECT * FROM user WHERE email=?";
        $existing = sql_query_sane($this->conn, $sql, [$email]);
        $num_existing = count($existing);

        if ($num_existing > 0) {
            $_user = $existing[0];
            return new User(
                $_user[0],
                $_user[1],
                $_user[2],
                $_user[3],
                $_user[4]
            );
        } else {
            echo redirect("/login");
            return new User(-1, null, null, null, null);
        }
    }

    public function register($email, $name, $username, $password) {
        // Check if user exists
        $sql = "SELECT * FROM user WHERE username=? OR email=?";
        $existing = sql_query_sane($this->conn, $sql, [$username, $email]);
        $num_existing = count($existing);

        // If user exists, redirect to the same page, raise alert?
        if ($num_existing > 0) {
            return new User(-1, null, null, null, null);
        } else {
            // Build new user in db
            $sql = "INSERT INTO user (username, name, email, password) VALUES (?, ?, ?, ?)";
            $id = sql_commit_sane($this->conn, $sql, [$username, $name, $email, $password]);

            return new User($id, $email, $name, $username, $password);
        }
    }

    public function getByID($id) {
        $user = $repo->getByID($id);
        return new User(
            $user[0],
            $user[1],
            $user[2],
            $user[3],
            $user[4]
        );
    }
}

?>
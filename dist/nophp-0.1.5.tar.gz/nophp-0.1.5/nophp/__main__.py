from nophp.spindle import app

app.run()